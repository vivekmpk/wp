<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_cf7database' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'gl:.X%D2{;8H`|>]k<?wvuULsh/su+8N%pkZJM.B=Y1{7XdsGo@Gr`Nh ]^`q:c6' );
define( 'SECURE_AUTH_KEY',  '#}a2{,ut38^OaciD)xV F?r#i!P~JtPE-vW;.^fX=k1Coxi3/+.!CYj.Omyv01h3' );
define( 'LOGGED_IN_KEY',    'du_%Azd|PKp3T}#(WqTjlhk=0^+b`9K(f:v|6hVz{R3u6i`;U ?Ee_@*WS4:~@WZ' );
define( 'NONCE_KEY',        '_HlNY G%|G-`>7Rp,)&t{-~,7R=|M}2$ZgPz2`kP`.3T[x#L_p*ptw<NO&F(Rtz+' );
define( 'AUTH_SALT',        'HpP}Q+1p lR~5kkfh,o_t(lOiV&A7b4C,`S,3|d5-Z[b$y(:gjR0c^&0FJ;jINL5' );
define( 'SECURE_AUTH_SALT', 'iv,qQ j;xgV<Y51r<03cAz<XA:Q3Nyjcx&Q%;^@(Pp.w{uTZiro;k4>aLZ}0ksho' );
define( 'LOGGED_IN_SALT',   'l1t`J>q>pS&]~pJgI Kc=8f!.H#2cjRdIZ<gk2`7/tKGOHbID!akO+Q-7~%luh#}' );
define( 'NONCE_SALT',       '-mi>`xAc0w.&f{oI)>3*{pFLO[|Lfk3c,%IG}aC0|aaxnthOE$/HZ~V4&q)s3bls' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
